# FFmpeg 参数参考

## 目录
1. [基础概念](#基础概念)
2. [常用参数详解](#常用参数详解)
3. [常见场景示例](#常见场景示例)
4. [参数速查表](#参数速查表)

## 基础概念

FFmpeg 是一个功能强大的多媒体处理工具，可以处理视频、音频、图片等多种格式。基本命令格式：

```bash
ffmpeg [全局选项] [输入选项] -i 输入文件 [输出选项] 输出文件
```

## 常用参数详解

### 输入输出选项

| 参数 | 说明 | 示例 |
|------|------|------|
| `-i` | 指定输入文件 | `-i input.mp4` |
| `-y` | 覆盖输出文件而不询问 | `-y` |
| `-n` | 不覆盖已存在的输出文件 | `-n` |

### 视频编码选项

| 参数 | 说明 | 示例 |
|------|------|------|
| `-c:v` | 视频编解码器 | `-c:v libx264` |
| `-b:v` | 视频比特率 | `-b:v 1M` |
| `-crf` | 恒定质量因子（18-28，值越小质量越高） | `-crf 24` |
| `-r` | 帧率 | `-r 30` |
| `-s` | 视频分辨率 | `-s 1920x1080` |
| `-vf` | 视频滤镜 | `-vf scale=1280:-2` |
| `-preset` | 编码速度预设（ultrafast, superfast, veryfast, faster, fast, medium, slow, slower, veryslow） | `-preset medium` |

### 音频编码选项

| 参数 | 说明 | 示例 |
|------|------|------|
| `-c:a` | 音频编解码器 | `-c:a aac` |
| `-b:a` | 音频比特率 | `-b:a 128k` |
| `-ar` | 音频采样率 | `-ar 44100` |
| `-ac` | 音频声道数 | `-ac 2` |
| `-an` | 禁用音频 | `-an` |
| `-vn` | 禁用视频 | `-vn` |

### 时间相关选项

| 参数 | 说明 | 示例 |
|------|------|------|
| `-ss` | 开始时间（输入或输出前） | `-ss 00:00:10` |
| `-t` | 持续时间 | `-t 00:01:00` |
| `-to` | 结束时间 | `-to 00:01:00` |
| `-ts` | 时间戳单位 | `-ts 1` |

### 格式选项

| 参数 | 说明 | 示例 |
|------|------|------|
| `-f` | 指定格式 | `-f mp4` |
| `-movflags` | MOV 格式标志 | `-movflags +faststart` |

## 常见场景示例

### 1. 格式转换

```bash
# MP4 转 AVI
ffmpeg -i input.mp4 output.avi

# MP4 转 MKV（复制流，不重新编码）
ffmpeg -i input.mp4 -c copy output.mkv

# 转换为特定的编码格式
ffmpeg -i input.mp4 -c:v libx264 -c:a aac output.mp4
```

### 2. 分辨率调整

```bash
# 调整为指定分辨率
ffmpeg -i input.mp4 -s 1280x720 output.mp4

# 按比例缩放（保持宽高比）
ffmpeg -i input.mp4 -vf scale=1280:-2 output.mp4  # -2 表示自动计算

# 按高度缩放
ffmpeg -i input.mp4 -vf scale=-2:720 output.mp4

# 缩小到原始尺寸的一半
ffmpeg -i input.mp4 -vf scale=iw/2:ih/2 output.mp4
```

### 3. 视频剪辑

```bash
# 从 10 秒开始，持续 50 秒
ffmpeg -i input.mp4 -ss 00:00:10 -t 00:00:50 output.mp4

# 从 10 秒到 1 分钟
ffmpeg -i input.mp4 -ss 00:00:10 -to 00:01:00 output.mp4

# 快速剪辑（-ss 在 -i 之前，更快但可能不精确）
ffmpeg -ss 00:00:10 -i input.mp4 -t 00:00:50 output.mp4
```

### 4. 视频压缩

```bash
# 使用 CRF 压缩（推荐）
ffmpeg -i input.mp4 -vcodec libx264 -crf 24 output.mp4

# 使用比特率压缩
ffmpeg -i input.mp4 -vcodec libx264 -b:v 1M -maxrate 1M -bufsize 2M output.mp4

# 两段式压缩（更高质量）
ffmpeg -i input.mp4 -vcodec libx264 -crf 18 -preset slow output.mp4

# 仅调整音频比特率
ffmpeg -i input.mp4 -b:a 128k output.mp4
```

### 5. 提取音频

```bash
# 提取音频为 MP3
ffmpeg -i input.mp4 -vn -acodec libmp3lame output.mp3

# 提取音频为 AAC
ffmpeg -i input.mp4 -vn -acodec aac output.aac

# 提取音频为 WAV（无损）
ffmpeg -i input.mp4 -vn -acodec pcm_s16le output.wav

# 复制音频流（不重新编码）
ffmpeg -i input.mp4 -vn -acodec copy output.aac
```

### 6. 视频拼接

```bash
# 方法 1：使用 concat 协议（快速但格式必须一致）
ffmpeg -f concat -i filelist.txt -c copy output.mp4
# filelist.txt 内容：
# file 'input1.mp4'
# file 'input2.mp4'
# file 'input3.mp4'

# 方法 2：使用 concat 滤镜（更灵活）
ffmpeg -i input1.mp4 -i input2.mp4 -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[outv][outa]" -map "[outv]" -map "[outa]" output.mp4
```

### 7. 提取视频帧

```bash
# 每 1 秒提取一帧
ffmpeg -i input.mp4 -vf fps=1 frame_%04d.png

# 提取特定时间的帧
ffmpeg -i input.mp4 -ss 00:00:10 -vframes 1 frame.png

# 提取为高质量 JPEG
ffmpeg -i input.mp4 -q:v 2 frame_%04d.jpg
```

### 8. 添加水印

```bash
# 添加图片水印（右下角）
ffmpeg -i input.mp4 -i watermark.png -filter_complex "overlay=(main_w-overlay_w-10):(main_h-overlay_h-10)" output.mp4

# 添加文字水印
ffmpeg -i input.mp4 -vf "drawtext=text='Watermark':fontcolor=white:fontsize=24:x=10:y=10" output.mp4
```

### 9. 视频旋转和翻转

```bash
# 顺时针旋转 90 度
ffmpeg -i input.mp4 -vf "transpose=1" output.mp4

# 水平翻转
ffmpeg -i input.mp4 -vf "hflip" output.mp4

# 垂直翻转
ffmpeg -i input.mp4 -vf "vflip" output.mp4
```

### 10. 调整速度

```bash
# 加速 2 倍
ffmpeg -i input.mp4 -filter:v "setpts=0.5*PTS" output.mp4

# 减速 0.5 倍
ffmpeg -i input.mp4 -filter:v "setpts=2.0*PTS" output.mp4

# 音频同时加速
ffmpeg -i input.mp4 -filter:v "setpts=0.5*PTS" -filter:a "atempo=2.0" output.mp4
```

### 11. 批量处理

```bash
# 批量转换目录中的所有 MP4 文件为 AVI
for file in *.mp4; do
    ffmpeg -i "$file" "${file%.mp4}.avi"
done
```

## 参数速查表

### 编码器常用值

- 视频编码器：`libx264` (H.264), `libx265` (H.265), `libvpx` (VP8), `libvpx-vp9` (VP9)
- 音频编码器：`aac`, `libmp3lame` (MP3), `libopus` (Opus), `pcm_s16le` (WAV)

### 常用分辨率

- 4K: `3840x2160`
- 1080p: `1920x1080`
- 720p: `1280x720`
- 480p: `854x480`
- 360p: `640x360`

### 常用比特率

- 4K 视频：8-20 Mbps
- 1080p 视频：3-6 Mbps
- 720p 视频：1.5-3 Mbps
- 480p 视频：0.8-1.5 Mbps
- 音频：128-320 kbps

### CRF 质量值

- 18-23: 高质量（原始大小约 60-80%）
- 24-28: 中等质量（推荐）
- 29-35: 低质量

### 预设速度

- `ultrafast`: 最快，压缩率最低
- `veryfast`, `faster`, `fast`: 较快
- `medium`: 默认
- `slow`, `slower`, `veryslow`: 较慢，压缩率最高

## 注意事项

1. **编码速度与质量权衡**：
   - 预设越慢，压缩率越高，质量越好
   - CRF 值越小，质量越好，文件越大

2. **格式兼容性**：
   - Web 播放推荐：H.264 + AAC + MP4 容器
   - 高质量存储推荐：H.265 + AAC + MKV 容器
   - Apple 设备推荐：H.264 + AAC + MOV 容器（添加 `-movflags +faststart`）

3. **性能优化**：
   - 对于快速剪辑，将 `-ss` 放在 `-i` 之前
   - 对于精确剪辑，将 `-ss` 放在 `-i` 之后
   - 使用 `-threads` 参数控制线程数

4. **常见错误**：
   - "Unsupported codec"：输入或输出格式不支持该编码器
   - "Invalid data"：输入文件损坏或格式错误
   - "Conversion failed!"：参数错误或编码器不支持
