---
name: video-processor
description: 使用 FFmpeg 处理视频，支持格式转换、分辨率调整、剪辑、压缩等视频处理任务
dependency:
  system:
    - ffmpeg -version
---

# Video Processor

## 任务目标
- 本 Skill 用于：使用 FFmpeg 进行视频格式转换、分辨率调整、剪辑、压缩等处理
- 能力包含：视频格式转换、分辨率调整、视频剪辑、视频压缩、音频提取、视频拼接
- 触发条件：用户需要处理视频文件，包括"转换视频格式"、"调整视频分辨率"、"剪辑视频片段"、"压缩视频大小"、"提取视频中的音频"、"拼接多个视频"等

## 前置准备
- 依赖说明：FFmpeg 必须已安装在系统中
  ```bash
  # 检查 FFmpeg 是否已安装
  ffmpeg -version
  ```
- 系统依赖：无需额外 Python 依赖（使用标准库 subprocess）

## 操作步骤
- 标准流程：
  1. **理解用户需求**
     - 智能体根据用户的描述（如"将 MP4 转换为 AVI"、"调整为 720p"）明确处理需求
     - 确定输入文件路径和输出文件路径

  2. **生成 FFmpeg 命令**
     - 根据需求参考 [references/ffmpeg-guide.md](references/ffmpeg-guide.md) 中的参数说明
     - 常见场景参考：
       - 格式转换：指定输出格式（如 `-f mp4`）或通过输出文件扩展名自动识别
       - 分辨率调整：使用 `-s` 参数（如 `-s 1280x720`）或 `-vf scale`（如 `-vf scale=1280:-2`）
       - 剪辑：使用 `-ss` 开始时间、`-t` 持续时间、`-to` 结束时间
       - 压缩：使用 `-crf` 参数（18-28，值越小质量越高）、`-b:v` 比特率
       - 提取音频：使用 `-vn` 禁用视频、`-acodec copy` 复制音频流
       - 视频拼接：使用 `concat` 协议或滤镜

  3. **执行 FFmpeg 命令**
     - 调用 `scripts/ffmpeg_processor.py` 执行 FFmpeg 命令
     - 参数说明：
       - `--command`: 完整的 FFmpeg 命令（不包括 `ffmpeg` 前缀）
       - `--input`: 输入文件路径（多个文件用空格分隔）
       - `--output`: 输出文件路径
       - `--verbose`: 是否显示详细输出（可选）

  4. **验证处理结果**
     - 检查输出文件是否生成
     - 验证输出文件的格式和质量是否符合预期
     - 如需进一步处理，重复上述步骤

## 资源索引
- 必要脚本：见 [scripts/ffmpeg_processor.py](scripts/ffmpeg_processor.py)（执行 FFmpeg 命令，处理输出和错误）
- 领域参考：见 [references/ffmpeg-guide.md](references/ffmpeg-guide.md)（FFmpeg 参数详解和常见命令示例）
- 输出资产：处理后的视频文件直接保存到用户指定的路径

## 注意事项
- 仅在需要详细参数时读取参考文档，保持上下文简洁。
- FFmpeg 命令参数复杂，建议先在参考文档中确认参数用法。
- 智能体负责理解需求并生成正确的参数，脚本负责执行命令。
- 处理大文件可能需要较长时间，脚本会实时显示进度。
- 确保输入文件路径正确且具有读取权限。

## 使用示例

### 示例 1：格式转换
- **功能说明**：将视频从一种格式转换为另一种格式
- **执行方式**：智能体生成参数 + 脚本执行
- **关键参数**：输出文件扩展名或 `-f` 参数
```bash
# 将 MP4 转换为 AVI
python scripts/ffmpeg_processor.py --input video.mp4 --output video.avi --command "-c:v libx264 -c:a aac"
```

### 示例 2：分辨率调整
- **功能说明**：调整视频分辨率到指定尺寸
- **执行方式**：智能体生成参数 + 脚本执行
- **关键参数**：`-s` 或 `-vf scale`
```bash
# 调整为 720p
python scripts/ffmpeg_processor.py --input video.mp4 --output video_720p.mp4 --command "-vf scale=1280:-2"
```

### 示例 3：视频剪辑
- **功能说明**：裁剪视频的指定时间段
- **执行方式**：智能体生成参数 + 脚本执行
- **关键参数**：`-ss`（开始时间）、`-t`（持续时间）、`-to`（结束时间）
```bash
# 裁剪 00:00:10 到 00:01:00 的片段
python scripts/ffmpeg_processor.py --input video.mp4 --output clip.mp4 --command "-ss 00:00:10 -to 00:01:00"
```

### 示例 4：视频压缩
- **功能说明**：压缩视频文件大小，控制质量和体积
- **执行方式**：智能体生成参数 + 脚本执行
- **关键参数**：`-crf`（18-28）、`-b:v`（比特率）
```bash
# 使用 CRF 24 压缩视频
python scripts/ffmpeg_processor.py --input video.mp4 --output compressed.mp4 --command "-vcodec libx264 -crf 24"
```
