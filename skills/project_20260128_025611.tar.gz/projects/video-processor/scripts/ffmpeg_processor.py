#!/usr/bin/env python3
"""
FFmpeg 视频处理器
封装 FFmpeg 命令行工具，提供统一的视频处理接口
"""

import argparse
import subprocess
import sys
import os


def execute_ffmpeg(command, input_files, output_file, verbose=False):
    """
    执行 FFmpeg 命令
    
    参数:
        command: FFmpeg 命令参数（不包括 ffmpeg 前缀）
        input_files: 输入文件列表
        output_file: 输出文件路径
        verbose: 是否显示详细输出
        
    返回:
        执行结果字典，包含 success、stdout、stderr、output_file
    """
    
    # 构建完整的 FFmpeg 命令
    ffmpeg_cmd = ["ffmpeg", "-y"]  # -y 表示覆盖输出文件而不询问
    
    # 添加输入文件
    for input_file in input_files.split():
        ffmpeg_cmd.extend(["-i", input_file])
    
    # 添加用户指定的命令参数
    if command:
        ffmpeg_cmd.extend(command.split())
    
    # 添加输出文件
    ffmpeg_cmd.append(output_file)
    
    # 执行命令
    if verbose:
        print(f"执行命令: {' '.join(ffmpeg_cmd)}")
    
    try:
        # 实时输出进度
        process = subprocess.Popen(
            ffmpeg_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        # 实时读取输出
        for line in process.stdout:
            if verbose:
                print(line, end='')
            # 过滤进度信息（包含 frame= time= 等关键字的行）
            if 'time=' in line and 'bitrate=' in line:
                if verbose:
                    print(line.strip())
        
        process.wait()
        
        if process.returncode == 0:
            # 检查输出文件是否存在
            if os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                file_size_mb = file_size / (1024 * 1024)
                return {
                    "success": True,
                    "output_file": output_file,
                    "file_size_mb": round(file_size_mb, 2),
                    "message": f"视频处理成功，输出文件: {output_file} ({file_size_mb:.2f} MB)"
                }
            else:
                return {
                    "success": False,
                    "error": "命令执行成功但输出文件未生成"
                }
        else:
            return {
                "success": False,
                "error": f"FFmpeg 执行失败，返回码: {process.returncode}"
            }
            
    except FileNotFoundError:
        return {
            "success": False,
            "error": "FFmpeg 未安装或不在系统路径中。请先安装 FFmpeg。"
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"执行出错: {str(e)}"
        }


def main():
    parser = argparse.ArgumentParser(description='FFmpeg 视频处理器')
    parser.add_argument('--command', type=str, help='FFmpeg 命令参数（不包括 ffmpeg 前缀）')
    parser.add_argument('--input', type=str, required=True, help='输入文件路径（多个文件用空格分隔）')
    parser.add_argument('--output', type=str, required=True, help='输出文件路径')
    parser.add_argument('--verbose', action='store_true', help='显示详细输出')
    
    args = parser.parse_args()
    
    # 验证输入文件
    input_files = args.input.strip()
    for input_file in input_files.split():
        if not os.path.exists(input_file):
            print(f"错误: 输入文件不存在: {input_file}")
            sys.exit(1)
    
    # 执行 FFmpeg 命令
    result = execute_ffmpeg(
        command=args.command or "",
        input_files=input_files,
        output_file=args.output,
        verbose=args.verbose
    )
    
    # 输出结果
    if result["success"]:
        print(result["message"])
        sys.exit(0)
    else:
        print(f"错误: {result['error']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
